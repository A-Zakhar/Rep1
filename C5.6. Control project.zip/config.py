
TOKEN = "6211792400:AAFghX4P77TEtj-WglWjzvllnAKAz0YEP-0"

exchanges = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB'
}